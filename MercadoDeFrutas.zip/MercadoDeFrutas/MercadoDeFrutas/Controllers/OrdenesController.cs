﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MercadoDeFrutas.Models;

namespace MercadoDeFrutas.Controllers
{
    public class OrdenesController : Controller
    {
        private readonly MercadoFrutasContext _context;

        public OrdenesController(MercadoFrutasContext context)
        {
            _context = context;
        }

        // GET: Ordenes
        public async Task<IActionResult> Index()
        {
            var mercadoFrutasContext = _context.Ordenes.Include(o => o.Frutas);
            return View(await mercadoFrutasContext.ToListAsync());
        }

        // GET: Ordenes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ordenes = await _context.Ordenes
                .Include(o => o.Frutas)
                .FirstOrDefaultAsync(m => m.IdOrden == id);
            if (ordenes == null)
            {
                return NotFound();
            }

            return View(ordenes);
        }

        // GET: Ordenes/Create
        public IActionResult Create()
        {
            ViewData["IdFruta"] = new SelectList(_context.Frutas, "IdFruta", "Nombre");
            return View();
        }

        // POST: Ordenes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdOrden,NombreCliente,Telefono,IdFruta,Cantidad")] Ordenes ordenes)
        {
            if (ModelState.IsValid)
            {
                _context.Add(ordenes);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdFruta"] = new SelectList(_context.Frutas, "IdFruta", "Nombre", ordenes.IdFruta);
            return View(ordenes);
        }

        // GET: Ordenes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ordenes = await _context.Ordenes.FindAsync(id);
            if (ordenes == null)
            {
                return NotFound();
            }
            ViewData["IdFruta"] = new SelectList(_context.Frutas, "IdFruta", "Nombre", ordenes.IdFruta);
            return View(ordenes);
        }

        // POST: Ordenes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdOrden,NombreCliente,Telefono,IdFruta,Cantidad")] Ordenes ordenes)
        {
            if (id != ordenes.IdOrden)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(ordenes);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OrdenesExists(ordenes.IdOrden))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdFruta"] = new SelectList(_context.Frutas, "IdFruta", "Nombre", ordenes.IdFruta);
            return View(ordenes);
        }

        // GET: Ordenes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ordenes = await _context.Ordenes
                .Include(o => o.Frutas)
                .FirstOrDefaultAsync(m => m.IdOrden == id);
            if (ordenes == null)
            {
                return NotFound();
            }

            return View(ordenes);
        }

        // POST: Ordenes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var ordenes = await _context.Ordenes.FindAsync(id);
            _context.Ordenes.Remove(ordenes);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OrdenesExists(int id)
        {
            return _context.Ordenes.Any(e => e.IdOrden == id);
        }
    }
}
