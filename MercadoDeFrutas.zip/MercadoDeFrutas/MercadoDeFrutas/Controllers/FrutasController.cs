﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MercadoDeFrutas.Models;

namespace MercadoDeFrutas.Controllers
{
    public class FrutasController : Controller
    {
        private readonly MercadoFrutasContext _context;

        public FrutasController(MercadoFrutasContext context)
        {
            _context = context;
        }

        // GET: Frutas
        public async Task<IActionResult> Index()
        {
            return View(await _context.Frutas.ToListAsync());
        }
        [HttpGet]
        public async Task<IActionResult> Index(string frutasearch)
        {
            ViewData["SearchFrutas"] = frutasearch;

            var frutaquery = from x in _context.Frutas select x;
            if (!String.IsNullOrEmpty(frutasearch))
            {
                frutaquery = frutaquery.Where(x => x.Nombre.Contains(frutasearch));
            }
            return View(await frutaquery.AsNoTracking().ToListAsync());
        }

        // GET: Frutas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var frutas = await _context.Frutas
                .FirstOrDefaultAsync(m => m.IdFruta == id);
            if (frutas == null)
            {
                return NotFound();
            }
                //var frutas = _context.Frutas.Where(m => m.IdFruta == id).FirstOrDefault();

                //return View(frutas);
                return PartialView("_DetailsModelPartial", frutas);
        }

        // GET: Frutas/Create
        public IActionResult Create()
        {
            Frutas frutas = new Frutas();
            return PartialView("_CreateModelPartial", frutas);
        }

        // POST: Frutas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdFruta,TipoFruta,Nombre,Cantidad,Estado")] Frutas frutas)
        {
            if (ModelState.IsValid)
            {
                _context.Add(frutas);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return PartialView("_CreateModelPartial", frutas);
        }

        // GET: Frutas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var frutas = await _context.Frutas.FindAsync(id);
            if (frutas == null)
            {
                return NotFound();
            }
            return PartialView("_EditModelPartial", frutas);
        }

        // POST: Frutas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdFruta,TipoFruta,Nombre,Cantidad,Estado")] Frutas frutas)
        {
            if (id != frutas.IdFruta)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(frutas);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FrutasExists(frutas.IdFruta))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return PartialView("_EditModelPartial", frutas);
        }

        // GET: Frutas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var frutas = await _context.Frutas
                .FirstOrDefaultAsync(m => m.IdFruta == id);
            if (frutas == null)
            {
                return NotFound();
            }

            return PartialView("_DeleteModelPartial", frutas);
        }

        // POST: Frutas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var frutas = await _context.Frutas.FindAsync(id);
            _context.Frutas.Remove(frutas);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
            //return PartialView("_DeleteModelPartial", frutas);
        }

        private bool FrutasExists(int id)
        {
            return _context.Frutas.Any(e => e.IdFruta == id);
        }
    }
}
