﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace MercadoDeFrutas.Models
{
    public partial class MercadoFrutasContext : DbContext
    {
        public MercadoFrutasContext()
        {
        }

        public MercadoFrutasContext(DbContextOptions<MercadoFrutasContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Frutas> Frutas { get; set; }
        public virtual DbSet<Ordenes> Ordenes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data source=DESKTOP-GTK2UAQ\\MIGUELSQL; Initial Catalog=MercadoFrutas; user id=sa; password=123456789;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Frutas>(entity =>
            {
                entity.HasKey(e => e.IdFruta)
                    .HasName("PK__Frutas__E1B2A12F14952D2F");

                entity.Property(e => e.Estado)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TipoFruta)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Ordenes>(entity =>
            {
                entity.HasKey(e => e.IdOrden)
                    .HasName("PK__Ordenes__C38F300D48A84BF8");

                entity.Property(e => e.NombreCliente)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.Frutas)
                    .WithMany(p => p.Ordenes)
                    .HasForeignKey(d => d.IdFruta)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Ordenes__IdFruta__267ABA7A");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
